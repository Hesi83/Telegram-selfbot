import os
from pyrogram import Client, filters
from pyrogram.types import Message

api_id = int(os.getenv("API_ID"))
api_hash = os.getenv("API_HASH")
session_name = "my_selfbot12"

app = Client(session_name, api_id=api_id, api_hash=api_hash)

messages = []
sending = False
repeat = False
interval = 3
target_chat = "me"

@app.on_message(filters.me & filters.command("add"))
async def add_message(_, message: Message):
    try:
        _, text = message.text.split(" ", 1)
        messages.append(text)
    except:
        await message.reply("❌ Failed to add message.")

app.run()
